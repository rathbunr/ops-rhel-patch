# Satellite Client Registration

Registers RHEL 8/9/10 clients to Red Hat Satellite via Global Registration
(`redhat.satellite.registration_command`), with service-account bootstrap and
local /etc/hosts resolution for DNS-restricted clients.

## Structure

```
satellite-registration/
├── README.md
├── satellite_registration.yml   # 3 plays: bootstrap -> generate -> register
├── inventory/
│   └── hosts.yml
└── vars/
    ├── main.yml                 # non-secret config
    └── vault.yml                # Satellite API creds (ansible-vault encrypt)
```

## Plays

1. **Bootstrap** (clients): create `svc_ansible` (UID 5000, password locked),
   deploy SSH pubkey (plain pubkey — no realm certificate services),
   NOPASSWD sudo drop-in with visudo validation, key-only sshd Match block,
   merged-config `sshd -t` validation before reload.
2. **Generate** (localhost): Global Registration command from the Satellite
   API. Requires API reachability from the control node / AAP EE.
3. **Register** (clients): /etc/hosts entry for the Satellite (clients cannot
   use DNS) with getent verification, conditional registration
   (`subscription-manager identity` rc), repo verification.

## Before first run

1. `vars/main.yml`: set `satellite_ip`, `svc_account_pubkey`, activation
   key(s), org; review FQDN/URL.
2. `vars/vault.yml`: set credentials, then `ansible-vault encrypt vars/vault.yml`.
   Use a least-privilege Satellite user with Register hosts permission —
   the JWT inherits that user's permissions.
3. `inventory/hosts.yml`: populate `satellite_clients`.
4. Verify module parameters against your EE's collection version:
   `ansible-doc redhat.satellite.registration_command`
   (confirm `location`, `jwt_expiration`, `smart_proxy`).

## Run

```bash
# Bootstrap run (existing ad hoc access)
ansible-playbook -i inventory/hosts.yml satellite_registration.yml \
  -e ansible_user=<adhoc_user> --ask-pass --ask-become-pass --ask-vault-pass

# Subsequent runs (svc_ansible, key auth — set in inventory)
ansible-playbook -i inventory/hosts.yml satellite_registration.yml \
  --ask-vault-pass
```

## AAP notes

- Custom Satellite API credential type required (injector -> extra_vars
  `satellite_username` / `satellite_password`); the built-in Red Hat
  Satellite credential type only serves the inventory plugin.
- For AAP, consider splitting Play 1 into its own job template (different
  machine credential than steady-state runs) and chaining via workflow.

## Requirements

- Collections in EE: `redhat.satellite`, `ansible.posix`
- Satellite 6.10+ (Global Registration); activation keys pre-created
- Note: `authorized_key` uses `exclusive: true` — removes other keys from
  the service account.
